package net.mikexxx.pmpport;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.StringRepresentable;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraftforge.registries.ForgeRegistries;

import javax.annotation.Nullable;

/**
 * Hanging plant that is 2 or 3 blocks tall. TOP is attached to a ceiling / chain / bracket / leaves,
 * the rest hangs below it. Breaking any part removes the whole plant.
 */
public class HangingPlantBlock extends Block {
    public enum Segment implements StringRepresentable {
        TOP("top"), MIDDLE("middle"), BOTTOM("bottom");
        private final String name;
        Segment(String n) { this.name = n; }
        @Override public String getSerializedName() { return name; }
    }

    public static final EnumProperty<Segment> SEGMENT = EnumProperty.create("segment", Segment.class);
    private static final VoxelShape SHAPE = Block.box(2.0D, 0.0D, 2.0D, 14.0D, 16.0D, 14.0D);
    private final int height;

    public HangingPlantBlock(Properties props, int height) {
        super(props);
        this.height = Math.max(2, Math.min(3, height));
        this.registerDefaultState(this.stateDefinition.any().setValue(SEGMENT, Segment.TOP));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(SEGMENT);
    }

    /** segment used at the given index below the top (0 = top) */
    private Segment segmentAt(int index) {
        if (index <= 0) return Segment.TOP;
        if (index >= height - 1) return Segment.BOTTOM;
        return Segment.MIDDLE;
    }

    private int indexOf(Segment s) {
        if (s == Segment.TOP) return 0;
        if (s == Segment.BOTTOM) return height - 1;
        return 1;
    }

    /** what the top half may hang from: solid undersides, centred supports, leaves, vanilla/modded chains, brackets, hooks */
    public static boolean canHangFrom(LevelReader level, BlockPos anchorPos) {
        BlockState s = level.getBlockState(anchorPos);
        if (s.is(Blocks.CHAIN) || s.is(BlockTags.LEAVES)) return true;
        ResourceLocation key = ForgeRegistries.BLOCKS.getKey(s.getBlock());
        if (key != null) {
            String p = key.getPath();
            if (p.contains("chain") || p.contains("bracket") || p.contains("hook")) return true;
        }
        return s.isFaceSturdy(level, anchorPos, Direction.DOWN) || Block.canSupportCenter(level, anchorPos, Direction.DOWN);
    }

    private boolean isPart(BlockState state, Segment expected) {
        return state.is(this) && state.getValue(SEGMENT) == expected;
    }

    @Override
    public boolean canSurvive(BlockState state, LevelReader level, BlockPos pos) {
        int i = indexOf(state.getValue(SEGMENT));
        if (i == 0) return canHangFrom(level, pos.above());
        return isPart(level.getBlockState(pos.above()), segmentAt(i - 1));
    }

    @Nullable
    @Override
    public BlockState getStateForPlacement(BlockPlaceContext ctx) {
        Level level = ctx.getLevel();
        BlockPos pos = ctx.getClickedPos();
        if (pos.getY() - (height - 1) <= level.getMinBuildHeight()) return null;
        for (int k = 1; k < height; k++) {
            if (!level.getBlockState(pos.below(k)).canBeReplaced(ctx)) return null;
        }
        BlockState state = this.defaultBlockState().setValue(SEGMENT, Segment.TOP);
        return state.canSurvive(level, pos) ? state : null;
    }

    @Override
    public void setPlacedBy(Level level, BlockPos pos, BlockState state, @Nullable LivingEntity placer, ItemStack stack) {
        for (int k = 1; k < height; k++) {
            level.setBlock(pos.below(k), this.defaultBlockState().setValue(SEGMENT, segmentAt(k)), 3);
        }
    }

    @Override
    public BlockState updateShape(BlockState state, Direction dir, BlockState neighbor, LevelAccessor level,
                                  BlockPos pos, BlockPos neighborPos) {
        int i = indexOf(state.getValue(SEGMENT));
        if (dir == Direction.UP) {
            if (i == 0) {
                if (!canHangFrom(level, neighborPos)) return Blocks.AIR.defaultBlockState();
            } else if (!isPart(neighbor, segmentAt(i - 1))) {
                return Blocks.AIR.defaultBlockState();
            }
        } else if (dir == Direction.DOWN && i < height - 1) {
            if (!isPart(neighbor, segmentAt(i + 1))) return Blocks.AIR.defaultBlockState();
        }
        return state;
    }

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        if (!level.isClientSide && player.isCreative()) {
            int i = indexOf(state.getValue(SEGMENT));
            BlockPos top = pos.above(i);
            for (int k = 0; k < height; k++) {
                BlockPos p = top.below(k);
                if (!p.equals(pos) && level.getBlockState(p).is(this)) {
                    level.setBlock(p, Blocks.AIR.defaultBlockState(), 35);
                }
            }
        }
        super.playerWillDestroy(level, pos, state, player);
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        return SHAPE;
    }
}
